﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormExemple1
{
    public partial class clientparvilleetpays : Form
    {
        private string pays;
        private string ville;
        public clientparvilleetpays()
        {
            InitializeComponent();
            InitCboPays();
            ShowLinq();
        }

        private void entityDataSource1_DataError(object sender, EFWinforms.DataErrorEventArgs e)
        {
            MessageBox.Show("Erreur :\r\n" + e.Exception.Message);
            entityDataSource1.CancelChanges();
            e.Handled = true;
        }

        public void InitCboPays()
        {
            using (var context = new NORTHWNDEntities())
            {
                var q = from c in context.Customers
                        select c.Country;
                List<String> ListePays = q.Distinct().ToList();
                comboBox1.DataSource = ListePays;
            }
        }

        public void InitCboVille()
        {
            using (var context = new NORTHWNDEntities())
            {
                var q = from c in context.Customers
                        where c.Country == comboBox1.Text
                        select c.City;
                List<String> ListeVille = q.Distinct().ToList();
                comboBox2.DataSource = ListeVille;
            }
        }
        void ShowLinq()
        {
            var q = from Customers c in entityDataSource1.EntitySets["Customers"]
                    where c.Country == comboBox1.Text
                    where c.City == comboBox2.Text
                    select new
                    {
                        CustomerID = c.CustomerID,
                        CompanyName = c.CompanyName,
                        ContactName = c.ContactName,
                        ContactTitle = c.ContactTitle,
                        Address = c.Address,
                        City = c.City,
                        Region = c.Region,
                        PostalCode = c.PostalCode,
                        Country = c.Country,
                        Phone = c.Phone,
                        Fax = c.Fax
                    };
            //CREATION DE LA VUE
            var bindingList = entityDataSource1.CreateView(q);
        }
        private void comboBox2_SelectedValueChanged_1(object sender, EventArgs e)
        {
            ShowLinq();
            ville = comboBox2.SelectedValue.ToString();
            applyFilter();
        }

        private void comboBox1_SelectedValueChanged_1(object sender, EventArgs e)
        {
            InitCboVille();
            ShowLinq();
            pays = comboBox1.SelectedValue.ToString();
            applyFilter();
        }

        void applyFilter()
        {
            if (!string.IsNullOrEmpty(pays))
            {
                clientbindingSource.Filter = string.Format("country = '{0}'", pays);
            }
            
            if (!string.IsNullOrEmpty(ville))
            {
                clientbindingSource.Filter = string.Format("city = '{0}' AND country = '{1}'", ville, pays);
            }
        }
    }
}
