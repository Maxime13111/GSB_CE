﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormExemple1
{
    public partial class Employees
    {
        public string FullName
        {
            get
            {
                return string.Format("{0}{1}", FirstName, LastName);
            }
        }

        public override string ToString()
        {
            return FullName;
        }
    }


    public partial class Order_Details
    {
        //calculate amount for this order detail
        public decimal Amount
        {
            get
            {
                return Quantity * UnitPrice * (1 - (decimal)Discount);
            }
        }
    }

    public partial class Orders
    {
        public decimal Amount
        {
            get
            {
                //format sugar
                var q = from od in this.Order_Details select od.Amount;
                return q.Sum();

                //return Order_Details.Sum(n => n.Amount);
            }
        }
    }

    public partial class Customers
    {
        public decimal Sales
        {
            get
            {
                //format sugar
                var q = from cu in this.Orders select cu.Amount;
                return q.Sum();

                //return Order_Details.Sum(n => n.Amount);
            }
        }
    }
}
